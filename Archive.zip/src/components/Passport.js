import React from 'react'

function Passport() {
    return (
        <div>
            <h1>Passport</h1>
        </div>
    )
}

export default Passport
