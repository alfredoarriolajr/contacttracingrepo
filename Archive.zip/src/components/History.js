import React from 'react'

function History() {
    return (
        <div>
            <h1>History</h1>
        </div>
    )
}

export default History
